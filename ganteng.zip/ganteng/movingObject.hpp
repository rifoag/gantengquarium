// Interface moving object
#ifndef _MOVING_OBJECT_H
#define _MOVING_OBJECT_H

class movingObject {
    // objek dapat bergerak, berubah posisinya
    virtual void move(double diff) = 0;
};

#endif
