public interface movingObject{
    public void move(double diff);
}